-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2021 at 08:05 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `easy farming`
--

-- --------------------------------------------------------

--
-- Table structure for table `animal info`
--

CREATE TABLE `animal info` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Pests and Diseases` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `crop information`
--

CREATE TABLE `crop information` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Pests and Diseases` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `farmer's info`
--

CREATE TABLE `farmer's info` (
  `ID` int(25) NOT NULL,
  `First Name` text NOT NULL,
  `Last Name` text NOT NULL,
  `Location` text NOT NULL,
  `District` text NOT NULL,
  `Contact` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `resource information`
--

CREATE TABLE `resource information` (
  `Type` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Market Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `support organisations`
--

CREATE TABLE `support organisations` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Type` text NOT NULL,
  `Contact` text NOT NULL,
  `Area of Operation` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `animal info`
--
ALTER TABLE `animal info`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `crop information`
--
ALTER TABLE `crop information`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `farmer's info`
--
ALTER TABLE `farmer's info`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `support organisations`
--
ALTER TABLE `support organisations`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
